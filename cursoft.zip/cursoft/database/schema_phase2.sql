-- Phase 2: Container Manager Database Schema
-- Run this in phpMyAdmin to add container management tables

USE cursoft;

-- Containers table
CREATE TABLE IF NOT EXISTS containers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    container_id VARCHAR(255) UNIQUE,
    container_name VARCHAR(255) NOT NULL,
    image VARCHAR(255) NOT NULL DEFAULT 'cursoft-dev:latest',
    status ENUM('created', 'running', 'stopped', 'paused', 'removed', 'error') DEFAULT 'created',
    port_mapping VARCHAR(255) COMMENT 'Format: host:container',
    environment_vars TEXT COMMENT 'JSON format',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    started_at TIMESTAMP NULL,
    stopped_at TIMESTAMP NULL,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_container_id (container_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Container logs table
CREATE TABLE IF NOT EXISTS container_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    container_id INT NOT NULL,
    log_level ENUM('info', 'warning', 'error', 'success', 'debug') DEFAULT 'info',
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (container_id) REFERENCES containers(id) ON DELETE CASCADE,
    INDEX idx_container_id (container_id),
    INDEX idx_created_at (created_at),
    INDEX idx_log_level (log_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

