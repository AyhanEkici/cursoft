-- Quick: Add OpenAI API Key
-- IMPORTANT: Replace YOUR_API_KEY_HERE with your actual API key
-- Run this in phpMyAdmin SQL tab

USE cursoft;

-- Add or update OpenAI API key
INSERT INTO llm_configs (user_id, provider, api_key, model, enabled) 
VALUES (1, 'openai', 'YOUR_API_KEY_HERE', 'gpt-3.5-turbo', 1)
ON DUPLICATE KEY UPDATE 
    api_key = 'YOUR_API_KEY_HERE',
    model = 'gpt-3.5-turbo',
    enabled = 1;

-- Verify
SELECT provider, enabled, 
       CASE 
           WHEN LENGTH(api_key) > 20 THEN CONCAT(SUBSTRING(api_key, 1, 8), '...', SUBSTRING(api_key, -4))
           ELSE '***'
       END as api_key_preview
FROM llm_configs 
WHERE user_id = 1 AND provider = 'openai';

