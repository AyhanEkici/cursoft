-- Phase 3: Safe Agent Toolkit & Execution Engine Database Schema
-- Run this in phpMyAdmin to add LLM and pipeline management tables

USE cursoft;

-- LLM API Requests tracking
CREATE TABLE IF NOT EXISTS llm_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT,
    provider VARCHAR(50) NOT NULL COMMENT 'openai, anthropic, google, deepseek, ollama',
    model VARCHAR(100) NOT NULL,
    prompt TEXT NOT NULL,
    response TEXT,
    tokens_input INT DEFAULT 0,
    tokens_output INT DEFAULT 0,
    tokens_total INT DEFAULT 0,
    cost_usd DECIMAL(10, 6) DEFAULT 0.000000,
    status ENUM('pending', 'completed', 'failed', 'timeout') DEFAULT 'pending',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
    INDEX idx_project_id (project_id),
    INDEX idx_provider (provider),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Pipeline stages tracking
CREATE TABLE IF NOT EXISTS pipeline_stages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    stage_name VARCHAR(100) NOT NULL COMMENT 'planning, coding, testing, deployment, etc.',
    stage_order INT NOT NULL,
    status ENUM('pending', 'running', 'completed', 'failed', 'skipped') DEFAULT 'pending',
    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    error_message TEXT,
    output_data TEXT COMMENT 'JSON format for stage results',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_status (status),
    INDEX idx_stage_order (stage_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Agent actions log
CREATE TABLE IF NOT EXISTS agent_actions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT,
    pipeline_stage_id INT,
    agent_type VARCHAR(50) NOT NULL COMMENT 'planner, coder, debugger, tester, etc.',
    action_type VARCHAR(100) NOT NULL COMMENT 'file_create, file_edit, code_execute, etc.',
    action_description TEXT,
    action_data TEXT COMMENT 'JSON format for action details',
    result ENUM('success', 'failed', 'warning') DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (pipeline_stage_id) REFERENCES pipeline_stages(id) ON DELETE SET NULL,
    INDEX idx_project_id (project_id),
    INDEX idx_agent_type (agent_type),
    INDEX idx_action_type (action_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

