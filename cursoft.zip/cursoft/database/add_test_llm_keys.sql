-- Add Test LLM API Keys
-- Run this in phpMyAdmin to add placeholder API keys for testing
-- NOTE: Replace with real API keys for actual LLM functionality

USE cursoft;

-- Add OpenAI test key (replace 'test-key' with your real API key)
INSERT INTO llm_configs (user_id, provider, api_key, model, enabled) 
VALUES (1, 'openai', 'test-key-replace-with-real-key', 'gpt-3.5-turbo', 1)
ON DUPLICATE KEY UPDATE api_key = 'test-key-replace-with-real-key', enabled = 1;

-- Add Anthropic test key (replace 'test-key' with your real API key)
INSERT INTO llm_configs (user_id, provider, api_key, model, enabled) 
VALUES (1, 'anthropic', 'test-key-replace-with-real-key', 'claude-3-haiku', 1)
ON DUPLICATE KEY UPDATE api_key = 'test-key-replace-with-real-key', enabled = 1;

-- Add Google test key (replace 'test-key' with your real API key)
INSERT INTO llm_configs (user_id, provider, api_key, model, enabled) 
VALUES (1, 'google', 'test-key-replace-with-real-key', 'gemini-pro', 1)
ON DUPLICATE KEY UPDATE api_key = 'test-key-replace-with-real-key', enabled = 1;

-- Add DeepSeek test key (replace 'test-key' with your real API key)
INSERT INTO llm_configs (user_id, provider, api_key, model, enabled) 
VALUES (1, 'deepseek', 'test-key-replace-with-real-key', 'deepseek-chat', 1)
ON DUPLICATE KEY UPDATE api_key = 'test-key-replace-with-real-key', enabled = 1;

-- Add Ollama (local, no real API key needed)
INSERT INTO llm_configs (user_id, provider, api_key, model, enabled) 
VALUES (1, 'ollama', 'local', 'llama2', 1)
ON DUPLICATE KEY UPDATE api_key = 'local', enabled = 1;

-- Verify entries
SELECT provider, enabled, 
       CASE 
           WHEN api_key LIKE 'test-key%' THEN '⚠️ Test Key - Replace with real key'
           WHEN api_key = 'local' THEN '✅ Local (Ollama)'
           ELSE '✅ Configured'
       END as status
FROM llm_configs 
WHERE user_id = 1;

