-- Quick: Add One Test LLM Key
-- Run this in phpMyAdmin to add a test entry (will make the test pass)
-- Replace 'test-key' with a real API key when you have one

USE cursoft;

-- Add Ollama entry (works without real API key - it's local)
INSERT INTO llm_configs (user_id, provider, api_key, model, enabled) 
VALUES (1, 'ollama', 'local', 'llama2', 1)
ON DUPLICATE KEY UPDATE enabled = 1;

-- Or add OpenAI test entry (replace with real key later)
-- INSERT INTO llm_configs (user_id, provider, api_key, model, enabled) 
-- VALUES (1, 'openai', 'sk-test-key-replace-me', 'gpt-3.5-turbo', 1)
-- ON DUPLICATE KEY UPDATE enabled = 1;

-- Verify
SELECT provider, enabled, 
       CASE 
           WHEN api_key = 'local' THEN '✅ Local (Ollama) - No API key needed'
           WHEN api_key LIKE '%test%' THEN '⚠️ Test Key - Replace with real key'
           ELSE '✅ Configured'
       END as status
FROM llm_configs 
WHERE user_id = 1 AND enabled = 1;

