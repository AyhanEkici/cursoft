-- Cursoft PostgreSQL Migration (FIXED)
-- Generated: 2025-12-29
-- Source: MySQL database 'cursoft'
-- Fixed for PostgreSQL compatibility

-- Create ENUM types first
CREATE TYPE agent_result_enum AS ENUM ('success', 'failed', 'warning');
CREATE TYPE container_log_level_enum AS ENUM ('info', 'warning', 'error', 'success', 'debug');
CREATE TYPE container_status_enum AS ENUM ('created', 'running', 'stopped', 'paused', 'removed', 'error');
CREATE TYPE pipeline_stage_status_enum AS ENUM ('pending', 'running', 'completed', 'failed', 'skipped');
CREATE TYPE project_log_level_enum AS ENUM ('info', 'warning', 'error', 'success');
CREATE TYPE project_plan_status_enum AS ENUM ('pending', 'in_progress', 'completed', 'failed');
CREATE TYPE project_status_enum AS ENUM ('planning', 'active', 'completed', 'failed', 'paused');
CREATE TYPE llm_request_status_enum AS ENUM ('pending', 'completed', 'failed', 'timeout');

-- ============================================
-- Table: users
-- ============================================
DROP TABLE IF EXISTS "users" CASCADE;

CREATE TABLE "users" (
  "id" SERIAL PRIMARY KEY,
  "email" VARCHAR(255) NOT NULL UNIQUE,
  "password_hash" VARCHAR(255) NOT NULL,
  "name" VARCHAR(255) NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX "idx_email" ON "users" ("email");

-- ============================================
-- Table: projects
-- ============================================
DROP TABLE IF EXISTS "projects" CASCADE;

CREATE TABLE "projects" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL,
  "name" VARCHAR(255) NOT NULL,
  "prompt" TEXT NOT NULL,
  "status" project_status_enum DEFAULT 'planning',
  "progress" INTEGER DEFAULT 0,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "projects_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_user_id" ON "projects" ("user_id");
CREATE INDEX "idx_status" ON "projects" ("status");

-- ============================================
-- Table: project_plans
-- ============================================
DROP TABLE IF EXISTS "project_plans" CASCADE;

CREATE TABLE "project_plans" (
  "id" SERIAL PRIMARY KEY,
  "project_id" INTEGER NOT NULL,
  "task_order" INTEGER NOT NULL,
  "task_name" VARCHAR(255) NOT NULL,
  "task_description" TEXT DEFAULT NULL,
  "estimated_time" INTEGER DEFAULT NULL,
  "status" project_plan_status_enum DEFAULT 'pending',
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "project_plans_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_project_id" ON "project_plans" ("project_id");
CREATE INDEX "idx_status" ON "project_plans" ("status");

-- ============================================
-- Table: containers
-- ============================================
DROP TABLE IF EXISTS "containers" CASCADE;

CREATE TABLE "containers" (
  "id" SERIAL PRIMARY KEY,
  "project_id" INTEGER NOT NULL,
  "container_id" VARCHAR(255) DEFAULT NULL UNIQUE,
  "container_name" VARCHAR(255) NOT NULL,
  "image" VARCHAR(255) NOT NULL DEFAULT 'cursoft-dev:latest',
  "status" container_status_enum DEFAULT 'created',
  "port_mapping" VARCHAR(255) DEFAULT NULL,
  "environment_vars" TEXT DEFAULT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "started_at" TIMESTAMP NULL DEFAULT NULL,
  "stopped_at" TIMESTAMP NULL DEFAULT NULL,
  CONSTRAINT "containers_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_project_id" ON "containers" ("project_id");
CREATE INDEX "idx_container_id" ON "containers" ("container_id");
CREATE INDEX "idx_status" ON "containers" ("status");

-- ============================================
-- Table: container_logs
-- ============================================
DROP TABLE IF EXISTS "container_logs" CASCADE;

CREATE TABLE "container_logs" (
  "id" SERIAL PRIMARY KEY,
  "container_id" INTEGER NOT NULL,
  "log_level" container_log_level_enum DEFAULT 'info',
  "message" TEXT NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "container_logs_ibfk_1" FOREIGN KEY ("container_id") REFERENCES "containers" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_container_id" ON "container_logs" ("container_id");
CREATE INDEX "idx_created_at" ON "container_logs" ("created_at");
CREATE INDEX "idx_log_level" ON "container_logs" ("log_level");

-- ============================================
-- Table: llm_configs
-- ============================================
DROP TABLE IF EXISTS "llm_configs" CASCADE;

CREATE TABLE "llm_configs" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL,
  "provider" VARCHAR(50) NOT NULL,
  "api_key" VARCHAR(500) NOT NULL,
  "model" VARCHAR(100) DEFAULT NULL,
  "enabled" SMALLINT DEFAULT 1,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "llm_configs_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_user_id" ON "llm_configs" ("user_id");
CREATE INDEX "idx_provider" ON "llm_configs" ("provider");

-- ============================================
-- Table: llm_requests
-- ============================================
DROP TABLE IF EXISTS "llm_requests" CASCADE;

CREATE TABLE "llm_requests" (
  "id" SERIAL PRIMARY KEY,
  "project_id" INTEGER DEFAULT NULL,
  "provider" VARCHAR(50) NOT NULL,
  "model" VARCHAR(100) NOT NULL,
  "prompt" TEXT NOT NULL,
  "response" TEXT DEFAULT NULL,
  "tokens_input" INTEGER DEFAULT 0,
  "tokens_output" INTEGER DEFAULT 0,
  "tokens_total" INTEGER DEFAULT 0,
  "cost_usd" DECIMAL(10,6) DEFAULT 0.000000,
  "status" llm_request_status_enum DEFAULT 'pending',
  "error_message" TEXT DEFAULT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "completed_at" TIMESTAMP NULL DEFAULT NULL,
  CONSTRAINT "llm_requests_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE SET NULL
);

CREATE INDEX "idx_project_id" ON "llm_requests" ("project_id");
CREATE INDEX "idx_provider" ON "llm_requests" ("provider");
CREATE INDEX "idx_status" ON "llm_requests" ("status");
CREATE INDEX "idx_created_at" ON "llm_requests" ("created_at");

-- ============================================
-- Table: pipeline_stages
-- ============================================
DROP TABLE IF EXISTS "pipeline_stages" CASCADE;

CREATE TABLE "pipeline_stages" (
  "id" SERIAL PRIMARY KEY,
  "project_id" INTEGER NOT NULL,
  "stage_name" VARCHAR(100) NOT NULL,
  "stage_order" INTEGER NOT NULL,
  "status" pipeline_stage_status_enum DEFAULT 'pending',
  "started_at" TIMESTAMP NULL DEFAULT NULL,
  "completed_at" TIMESTAMP NULL DEFAULT NULL,
  "error_message" TEXT DEFAULT NULL,
  "output_data" TEXT DEFAULT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "pipeline_stages_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_project_id" ON "pipeline_stages" ("project_id");
CREATE INDEX "idx_status" ON "pipeline_stages" ("status");
CREATE INDEX "idx_stage_order" ON "pipeline_stages" ("stage_order");

-- ============================================
-- Table: agent_actions
-- ============================================
DROP TABLE IF EXISTS "agent_actions" CASCADE;

CREATE TABLE "agent_actions" (
  "id" SERIAL PRIMARY KEY,
  "project_id" INTEGER DEFAULT NULL,
  "pipeline_stage_id" INTEGER DEFAULT NULL,
  "agent_type" VARCHAR(50) NOT NULL,
  "action_type" VARCHAR(100) NOT NULL,
  "action_description" TEXT DEFAULT NULL,
  "action_data" TEXT DEFAULT NULL,
  "result" agent_result_enum DEFAULT 'success',
  "error_message" TEXT DEFAULT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "agent_actions_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE CASCADE,
  CONSTRAINT "agent_actions_ibfk_2" FOREIGN KEY ("pipeline_stage_id") REFERENCES "pipeline_stages" ("id") ON DELETE SET NULL
);

CREATE INDEX "idx_project_id" ON "agent_actions" ("project_id");
CREATE INDEX "idx_agent_type" ON "agent_actions" ("agent_type");
CREATE INDEX "idx_action_type" ON "agent_actions" ("action_type");
CREATE INDEX "idx_created_at" ON "agent_actions" ("created_at");

-- ============================================
-- Table: project_logs
-- ============================================
DROP TABLE IF EXISTS "project_logs" CASCADE;

CREATE TABLE "project_logs" (
  "id" SERIAL PRIMARY KEY,
  "project_id" INTEGER NOT NULL,
  "log_level" project_log_level_enum DEFAULT 'info',
  "message" TEXT NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "project_logs_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_project_id" ON "project_logs" ("project_id");
CREATE INDEX "idx_created_at" ON "project_logs" ("created_at");

-- ============================================
-- Table: user_sessions
-- ============================================
DROP TABLE IF EXISTS "user_sessions" CASCADE;

CREATE TABLE "user_sessions" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL,
  "session_token" VARCHAR(255) NOT NULL UNIQUE,
  "ip_address" VARCHAR(45) DEFAULT NULL,
  "user_agent" TEXT DEFAULT NULL,
  "expires_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "last_activity" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "user_sessions_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_user_id" ON "user_sessions" ("user_id");
CREATE INDEX "idx_session_token" ON "user_sessions" ("session_token");
CREATE INDEX "idx_expires_at" ON "user_sessions" ("expires_at");

-- ============================================
-- Table: user_preferences
-- ============================================
DROP TABLE IF EXISTS "user_preferences" CASCADE;

CREATE TABLE "user_preferences" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL UNIQUE,
  "theme" VARCHAR(20) DEFAULT 'light',
  "language" VARCHAR(10) DEFAULT 'en',
  "notifications_enabled" SMALLINT DEFAULT 1,
  "email_notifications" SMALLINT DEFAULT 1,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "user_preferences_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_user_id" ON "user_preferences" ("user_id");

-- ============================================
-- Table: password_reset_tokens
-- ============================================
DROP TABLE IF EXISTS "password_reset_tokens" CASCADE;

CREATE TABLE "password_reset_tokens" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL,
  "token" VARCHAR(64) NOT NULL,
  "expires_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "used" SMALLINT DEFAULT 0,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "password_reset_tokens_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_token" ON "password_reset_tokens" ("token");
CREATE INDEX "idx_user_id" ON "password_reset_tokens" ("user_id");
CREATE INDEX "idx_expires_at" ON "password_reset_tokens" ("expires_at");

-- ============================================
-- Table: api_tokens
-- ============================================
DROP TABLE IF EXISTS "api_tokens" CASCADE;

CREATE TABLE "api_tokens" (
  "id" SERIAL PRIMARY KEY,
  "user_id" INTEGER NOT NULL,
  "token" VARCHAR(64) NOT NULL UNIQUE,
  "name" VARCHAR(255) DEFAULT NULL,
  "last_used_at" TIMESTAMP NULL DEFAULT NULL,
  "expires_at" TIMESTAMP NULL DEFAULT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "api_tokens_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

CREATE INDEX "idx_token" ON "api_tokens" ("token");
CREATE INDEX "idx_user_id" ON "api_tokens" ("user_id");

-- ============================================
-- Table: rate_limits
-- ============================================
DROP TABLE IF EXISTS "rate_limits" CASCADE;

CREATE TABLE "rate_limits" (
  "id" SERIAL PRIMARY KEY,
  "identifier" VARCHAR(100) NOT NULL,
  "ip_address" VARCHAR(45) NOT NULL,
  "request_count" INTEGER DEFAULT 1,
  "reset_time" INTEGER NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX "idx_identifier_ip" ON "rate_limits" ("identifier", "ip_address");
CREATE INDEX "idx_reset_time" ON "rate_limits" ("reset_time");

-- ============================================
-- Table: security_logs
-- ============================================
DROP TABLE IF EXISTS "security_logs" CASCADE;

CREATE TABLE "security_logs" (
  "id" SERIAL PRIMARY KEY,
  "event_type" VARCHAR(100) NOT NULL,
  "ip_address" VARCHAR(45) DEFAULT NULL,
  "user_agent" TEXT DEFAULT NULL,
  "user_id" INTEGER DEFAULT NULL,
  "event_data" JSONB DEFAULT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "security_logs_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE SET NULL
);

CREATE INDEX "idx_event_type" ON "security_logs" ("event_type");
CREATE INDEX "idx_user_id" ON "security_logs" ("user_id");
CREATE INDEX "idx_created_at" ON "security_logs" ("created_at");

-- ============================================
-- Create triggers for updated_at (PostgreSQL doesn't support ON UPDATE)
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON "users"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON "projects"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_containers_updated_at BEFORE UPDATE ON "containers"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_preferences_updated_at BEFORE UPDATE ON "user_preferences"
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- Import data (run the INSERT statements from original file)
-- ============================================
-- Note: You'll need to copy the INSERT statements from postgres-export.sql
-- and run them after creating the tables above

