-- Cursoft Complete Database Schema
-- Run this file to set up all phases at once
-- Or run schema.sql, schema_phase2.sql, and schema_phase3.sql separately

-- ============================================
-- PHASE 1: Base Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS cursoft CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cursoft;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    prompt TEXT NOT NULL,
    status ENUM('planning', 'active', 'completed', 'failed', 'paused') DEFAULT 'planning',
    progress INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Project plans (decomposed tasks)
CREATE TABLE IF NOT EXISTS project_plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    task_order INT NOT NULL,
    task_name VARCHAR(255) NOT NULL,
    task_description TEXT,
    estimated_time INT COMMENT 'Minutes',
    status ENUM('pending', 'in_progress', 'completed', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- LLM configurations
CREATE TABLE IF NOT EXISTS llm_configs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    provider VARCHAR(50) NOT NULL COMMENT 'openai, anthropic, google, deepseek, ollama',
    api_key VARCHAR(500) NOT NULL,
    model VARCHAR(100),
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_provider (provider)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Project logs
CREATE TABLE IF NOT EXISTS project_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    log_level ENUM('info', 'warning', 'error', 'success') DEFAULT 'info',
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert a test user for development
INSERT INTO users (email, password_hash, name) 
VALUES ('test@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Test User')
ON DUPLICATE KEY UPDATE email=email;

-- ============================================
-- PHASE 2: Container Manager
-- ============================================

-- Containers table
CREATE TABLE IF NOT EXISTS containers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    container_id VARCHAR(255) UNIQUE,
    container_name VARCHAR(255) NOT NULL,
    image VARCHAR(255) NOT NULL DEFAULT 'cursoft-dev:latest',
    status ENUM('created', 'running', 'stopped', 'paused', 'removed', 'error') DEFAULT 'created',
    port_mapping VARCHAR(255) COMMENT 'Format: host:container',
    environment_vars TEXT COMMENT 'JSON format',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    started_at TIMESTAMP NULL,
    stopped_at TIMESTAMP NULL,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_container_id (container_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Container logs table
CREATE TABLE IF NOT EXISTS container_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    container_id INT NOT NULL,
    log_level ENUM('info', 'warning', 'error', 'success', 'debug') DEFAULT 'info',
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (container_id) REFERENCES containers(id) ON DELETE CASCADE,
    INDEX idx_container_id (container_id),
    INDEX idx_created_at (created_at),
    INDEX idx_log_level (log_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- PHASE 3: LLM & Pipeline
-- ============================================

-- LLM API Requests tracking
CREATE TABLE IF NOT EXISTS llm_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT,
    provider VARCHAR(50) NOT NULL COMMENT 'openai, anthropic, google, deepseek, ollama',
    model VARCHAR(100) NOT NULL,
    prompt TEXT NOT NULL,
    response TEXT,
    tokens_input INT DEFAULT 0,
    tokens_output INT DEFAULT 0,
    tokens_total INT DEFAULT 0,
    cost_usd DECIMAL(10, 6) DEFAULT 0.000000,
    status ENUM('pending', 'completed', 'failed', 'timeout') DEFAULT 'pending',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
    INDEX idx_project_id (project_id),
    INDEX idx_provider (provider),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Pipeline stages tracking
CREATE TABLE IF NOT EXISTS pipeline_stages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    stage_name VARCHAR(100) NOT NULL COMMENT 'planning, coding, testing, deployment, etc.',
    stage_order INT NOT NULL,
    status ENUM('pending', 'running', 'completed', 'failed', 'skipped') DEFAULT 'pending',
    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    error_message TEXT,
    output_data TEXT COMMENT 'JSON format for stage results',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX idx_project_id (project_id),
    INDEX idx_status (status),
    INDEX idx_stage_order (stage_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Agent actions log
CREATE TABLE IF NOT EXISTS agent_actions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT,
    pipeline_stage_id INT,
    agent_type VARCHAR(50) NOT NULL COMMENT 'planner, coder, debugger, tester, etc.',
    action_type VARCHAR(100) NOT NULL COMMENT 'file_create, file_edit, code_execute, etc.',
    action_description TEXT,
    action_data TEXT COMMENT 'JSON format for action details',
    result ENUM('success', 'failed', 'warning') DEFAULT 'success',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (pipeline_stage_id) REFERENCES pipeline_stages(id) ON DELETE SET NULL,
    INDEX idx_project_id (project_id),
    INDEX idx_agent_type (agent_type),
    INDEX idx_action_type (action_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Setup Complete!
-- ============================================
-- You should now have 10 tables:
-- 1. users
-- 2. projects
-- 3. project_plans
-- 4. project_logs
-- 5. llm_configs
-- 6. containers
-- 7. container_logs
-- 8. llm_requests
-- 9. pipeline_stages
-- 10. agent_actions
-- ============================================

