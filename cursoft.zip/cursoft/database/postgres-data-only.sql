-- Cursoft PostgreSQL Data Import
-- Run this AFTER creating tables with postgres-export-fixed.sql
-- Contains only INSERT statements for data migration
-- Generated: 2025-12-29
-- IMPORTANT: Run AFTER postgres-export-fixed.sql

BEGIN;

-- Temporarily disable triggers for faster insertion
SET session_replication_role = 'replica';

-- ============================================
-- Data for container_logs (4 rows)
-- ============================================
INSERT INTO "container_logs" ("id", "container_id", "log_level", "message", "created_at") VALUES (1, 1, 'info', 'Container created: cursoft-project-3-1766964603', '2025-12-29 00:30:05');
INSERT INTO "container_logs" ("id", "container_id", "log_level", "message", "created_at") VALUES (2, 2, 'info', 'Container created: cursoft-project-1-1766964606', '2025-12-29 00:30:07');
INSERT INTO "container_logs" ("id", "container_id", "log_level", "message", "created_at") VALUES (3, 3, 'info', 'Container created: cursoft-project-5-1766964645', '2025-12-29 00:30:46');
INSERT INTO "container_logs" ("id", "container_id", "log_level", "message", "created_at") VALUES (4, 4, 'info', 'Container created: cursoft-project-1-1766964646', '2025-12-29 00:30:47');

-- ============================================
-- Data for containers (4 rows)
-- ============================================
INSERT INTO "containers" ("id", "project_id", "container_id", "container_name", "image", "status", "port_mapping", "environment_vars", "created_at", "updated_at", "started_at", "stopped_at") VALUES (1, 3, 'b4cdef4884459029eadb138ce9a022e656f53fd35ba3c705d3d6ab01849dadff', 'cursoft-project-3-1766964603', 'cursoft-dev:latest', 'error', '8000:80', '{"PROJECT_ID":3,"CURSOFT_ENV":"development"}', '2025-12-29 00:30:05', '2025-12-29 00:30:06', NULL, NULL);
INSERT INTO "containers" ("id", "project_id", "container_id", "container_name", "image", "status", "port_mapping", "environment_vars", "created_at", "updated_at", "started_at", "stopped_at") VALUES (2, 1, '9aa2414b6dfbda6b452f2a15d4eccb6c1c91a296a1dd457735b4792aafd03d41', 'cursoft-project-1-1766964606', 'cursoft-dev:latest', 'error', '8001:80', '{"PROJECT_ID":1,"CURSOFT_ENV":"development"}', '2025-12-29 00:30:07', '2025-12-29 00:30:46', NULL, NULL);
INSERT INTO "containers" ("id", "project_id", "container_id", "container_name", "image", "status", "port_mapping", "environment_vars", "created_at", "updated_at", "started_at", "stopped_at") VALUES (3, 5, 'b8644067872819e567326074c5914e1620e0589ef00adca0a27e573b4499f2b2', 'cursoft-project-5-1766964645', 'cursoft-dev:latest', 'created', '8002:80', '{"PROJECT_ID":5,"CURSOFT_ENV":"development"}', '2025-12-29 00:30:46', '2025-12-29 00:30:46', NULL, NULL);
INSERT INTO "containers" ("id", "project_id", "container_id", "container_name", "image", "status", "port_mapping", "environment_vars", "created_at", "updated_at", "started_at", "stopped_at") VALUES (4, 1, '525aa01139dac86971353d9c1730e070347daf700f640154772db8806c646aed', 'cursoft-project-1-1766964646', 'cursoft-dev:latest', 'created', '8003:80', '{"PROJECT_ID":1,"CURSOFT_ENV":"development"}', '2025-12-29 00:30:47', '2025-12-29 00:30:47', NULL, NULL);

-- ============================================
-- Data for llm_configs (8 rows)
-- ============================================
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES (1, 1, 'ollama', 'local', 'llama2', 1, '2025-12-29 00:44:02');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES (2, 1, 'openai', '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', '', 1, '2025-12-29 00:44:36');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES (3, 1, 'anthropic', 'test-key-replace-with-real-key', 'claude-3-haiku', 1, '2025-12-29 00:44:36');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES (4, 1, 'google', 'test-key-replace-with-real-key', 'gemini-pro', 1, '2025-12-29 00:44:36');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES (5, 1, 'deepseek', 'test-key-replace-with-real-key', 'deepseek-chat', 1, '2025-12-29 00:44:36');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES (6, 1, 'ollama', 'local', 'llama2', 1, '2025-12-29 00:44:36');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES (7, 1, 'ollama', 'local', 'llama2', 1, '2025-12-29 00:44:59');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES (8, 2, 'openai', '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', '', 1, '2025-12-29 01:03:33');

-- ============================================
-- Data for llm_requests (6 rows)
-- ============================================
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES (1, NULL, 'openai', '', 'Write a simple PHP function that calculates the factorial of a number.', NULL, 0, 0, 0, 0.000000, 'failed', 'API error (HTTP 401): {
    "error": {
        "message": "Incorrect API key provided: test-key******************-key. You can find your API key at https://platform.openai.com/account/api-keys.",
        "type": "invalid_request_error",
        "param": null,
        "code": "invalid_api_key"
    }
}
', '2025-12-29 00:45:46', '2025-12-29 00:45:46');
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES (2, NULL, 'anthropic', '', 'Write a simple PHP function that calculates the factorial of a number.', NULL, 0, 0, 0, 0.000000, 'failed', 'API error (HTTP 401): {"type":"error","error":{"type":"authentication_error","message":"invalid x-api-key"},"request_id":"req_011CWZyZBsH8svrh4bALwA8c"}', '2025-12-29 00:45:56', '2025-12-29 00:45:56');
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES (3, NULL, 'openai', '', 'Write a simple PHP function that calculates the factorial of a number.', NULL, 0, 0, 0, 0.000000, 'failed', 'API error (HTTP 401): {
    "error": {
        "message": "Incorrect API key provided: test-key******************-key. You can find your API key at https://platform.openai.com/account/api-keys.",
        "type": "invalid_request_error",
        "param": null,
        "code": "invalid_api_key"
    }
}
', '2025-12-29 00:47:29', '2025-12-29 00:47:29');
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES (4, NULL, 'openai', '', 'Write a simple PHP function that calculates the factorial of a number.', NULL, 0, 0, 0, 0.000000, 'failed', 'Invalid API key. Please check your API key in the LLM Configuration page. If you''re using a test key, replace it with a real API key from the provider.', '2025-12-29 00:47:58', '2025-12-29 00:47:58');
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES (5, NULL, 'openai', '', 'Write a simple PHP function that calculates the factorial of a number.', NULL, 0, 0, 0, 0.000000, 'failed', 'you must provide a model parameter', '2025-12-29 00:52:28', '2025-12-29 00:52:28');
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES (6, NULL, 'openai', 'gpt-3.5-turbo', 'Write a simple PHP function that calculates the factorial of a number.', '```php
function factorial($n) {
    if($n == 0) {
        return 1;
    } else {
        return $n * factorial($n - 1);
    }
}

// Example usage
echo factorial(5); // Output: 120
```', 20, 58, 78, 0.000146, 'completed', NULL, '2025-12-29 00:52:47', '2025-12-29 00:52:49');

-- ============================================
-- Data for pipeline_stages (7 rows)
-- ============================================
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES (1, 6, 'planning', 1, 'completed', '2025-12-29 01:02:43', '2025-12-29 01:02:43', NULL, '{"tasks":3,"message":"Planning completed"}', '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES (2, 6, 'environment', 2, 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES (3, 6, 'development', 3, 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES (4, 6, 'testing', 4, 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES (5, 6, 'integration', 5, 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES (6, 6, 'deployment', 6, 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES (7, 6, 'final', 7, 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');

-- ============================================
-- Data for project_logs (12 rows)
-- ============================================
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (1, 1, 'info', 'Project created: test1', '2025-12-28 23:54:32');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (2, 1, 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-28 23:54:32');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (3, 2, 'info', 'Project created: Test Project 1766964603', '2025-12-29 00:30:03');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (4, 2, 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-29 00:30:03');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (5, 3, 'info', 'Project created: Decomposition Test', '2025-12-29 00:30:03');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (6, 3, 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-29 00:30:03');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (7, 4, 'info', 'Project created: Test Project 1766964645', '2025-12-29 00:30:45');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (8, 4, 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-29 00:30:45');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (9, 5, 'info', 'Project created: Decomposition Test', '2025-12-29 00:30:45');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (10, 5, 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-29 00:30:45');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (11, 6, 'info', 'Project created: Ayhan', '2025-12-29 01:02:37');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES (12, 6, 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-29 01:02:37');

-- ============================================
-- Data for project_plans (30 rows)
-- ============================================
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (1, 1, 1, 'Project Setup', 'Initialize project structure and dependencies', 15, 'pending', '2025-12-28 23:54:32');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (2, 1, 2, 'Testing', 'Write and run unit and integration tests', 30, 'pending', '2025-12-28 23:54:32');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (3, 1, 3, 'Documentation', 'Create README and API documentation', 15, 'pending', '2025-12-28 23:54:32');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (4, 2, 1, 'Project Setup', 'Initialize project structure and dependencies', 15, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (5, 2, 2, 'Frontend Setup', 'Create HTML/CSS/JavaScript structure', 30, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (6, 2, 3, 'Backend API', 'Develop REST API endpoints', 45, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (7, 2, 4, 'Database Design', 'Create database schema and migrations', 20, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (8, 2, 5, 'Database Schema', 'Design and implement database structure', 25, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (9, 2, 6, 'Authentication System', 'Implement user registration and login', 40, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (10, 2, 7, 'Testing', 'Write and run unit and integration tests', 30, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (11, 2, 8, 'Documentation', 'Create README and API documentation', 15, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (12, 3, 1, 'Project Setup', 'Initialize project structure and dependencies', 15, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (13, 3, 2, 'API Development', 'Create RESTful API endpoints', 50, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (14, 3, 3, 'Testing', 'Write and run unit and integration tests', 30, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (15, 3, 4, 'Documentation', 'Create README and API documentation', 15, 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (16, 4, 1, 'Project Setup', 'Initialize project structure and dependencies', 15, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (17, 4, 2, 'Frontend Setup', 'Create HTML/CSS/JavaScript structure', 30, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (18, 4, 3, 'Backend API', 'Develop REST API endpoints', 45, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (19, 4, 4, 'Database Design', 'Create database schema and migrations', 20, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (20, 4, 5, 'Database Schema', 'Design and implement database structure', 25, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (21, 4, 6, 'Authentication System', 'Implement user registration and login', 40, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (22, 4, 7, 'Testing', 'Write and run unit and integration tests', 30, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (23, 4, 8, 'Documentation', 'Create README and API documentation', 15, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (24, 5, 1, 'Project Setup', 'Initialize project structure and dependencies', 15, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (25, 5, 2, 'API Development', 'Create RESTful API endpoints', 50, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (26, 5, 3, 'Testing', 'Write and run unit and integration tests', 30, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (27, 5, 4, 'Documentation', 'Create README and API documentation', 15, 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (28, 6, 1, 'Project Setup', 'Initialize project structure and dependencies', 15, 'pending', '2025-12-29 01:02:37');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (29, 6, 2, 'Testing', 'Write and run unit and integration tests', 30, 'pending', '2025-12-29 01:02:37');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES (30, 6, 3, 'Documentation', 'Create README and API documentation', 15, 'pending', '2025-12-29 01:02:37');

-- ============================================
-- Data for projects (6 rows)
-- ============================================
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES (1, 1, 'test1', 'test pagina hello ayhan', 'planning', 0, '2025-12-28 23:54:32', '2025-12-28 23:54:32');
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES (2, 1, 'Test Project 1766964603', 'Build a todo web app with user authentication and MySQL database', 'planning', 0, '2025-12-29 00:30:03', '2025-12-29 00:30:03');
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES (3, 1, 'Decomposition Test', 'Create a REST API for a blog system', 'planning', 0, '2025-12-29 00:30:03', '2025-12-29 00:30:03');
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES (4, 1, 'Test Project 1766964645', 'Build a todo web app with user authentication and MySQL database', 'planning', 0, '2025-12-29 00:30:45', '2025-12-29 00:30:45');
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES (5, 1, 'Decomposition Test', 'Create a REST API for a blog system', 'planning', 0, '2025-12-29 00:30:45', '2025-12-29 00:30:45');
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES (6, 2, 'Ayhan', 'create a hello Cursoft landingspage', 'active', 14, '2025-12-29 01:02:37', '2025-12-29 01:02:43');

-- ============================================
-- Data for user_preferences (1 row)
-- ============================================
INSERT INTO "user_preferences" ("id", "user_id", "theme", "language", "notifications_enabled", "email_notifications", "created_at", "updated_at") VALUES (1, 2, 'light', 'en', 1, 1, '2025-12-29 01:01:37', '2025-12-29 01:01:37');

-- ============================================
-- Data for user_sessions (1 row)
-- ============================================
INSERT INTO "user_sessions" ("id", "user_id", "session_token", "ip_address", "user_agent", "expires_at", "created_at", "last_activity") VALUES (1, 2, 'b53951d238ad7516687899116b0b4e8e676b61cebb54c568232610bcfc120e95', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.44 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-30 01:02:11', '2025-12-29 01:02:11', '2025-12-29 01:02:11');

-- ============================================
-- Data for users (2 rows)
-- ============================================
INSERT INTO "users" ("id", "email", "password_hash", "name", "created_at", "updated_at") VALUES (1, 'test@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Test User', '2025-12-28 23:52:02', '2025-12-28 23:52:02');
INSERT INTO "users" ("id", "email", "password_hash", "name", "created_at", "updated_at") VALUES (2, 'ayhan@ayhan.nl', '$2y$10$8BzFyfav10jaRUrnHQJT1u7hUlnDzwvASaeAXDorcl34BHCjdME16', 'ayhan', '2025-12-29 01:01:37', '2025-12-29 01:01:37');

-- ============================================
-- Reset sequences (important for SERIAL columns)
-- ============================================
SELECT setval('users_id_seq', (SELECT MAX(id) FROM "users"));
SELECT setval('projects_id_seq', (SELECT MAX(id) FROM "projects"));
SELECT setval('project_plans_id_seq', (SELECT MAX(id) FROM "project_plans"));
SELECT setval('containers_id_seq', (SELECT MAX(id) FROM "containers"));
SELECT setval('container_logs_id_seq', (SELECT MAX(id) FROM "container_logs"));
SELECT setval('llm_configs_id_seq', (SELECT MAX(id) FROM "llm_configs"));
SELECT setval('llm_requests_id_seq', (SELECT MAX(id) FROM "llm_requests"));
SELECT setval('pipeline_stages_id_seq', (SELECT MAX(id) FROM "pipeline_stages"));
SELECT setval('agent_actions_id_seq', (SELECT MAX(id) FROM "agent_actions"));
SELECT setval('project_logs_id_seq', (SELECT MAX(id) FROM "project_logs"));
SELECT setval('user_sessions_id_seq', (SELECT MAX(id) FROM "user_sessions"));
SELECT setval('user_preferences_id_seq', (SELECT MAX(id) FROM "user_preferences"));
SELECT setval('password_reset_tokens_id_seq', (SELECT MAX(id) FROM "password_reset_tokens"));
SELECT setval('api_tokens_id_seq', (SELECT MAX(id) FROM "api_tokens"));
SELECT setval('rate_limits_id_seq', (SELECT MAX(id) FROM "rate_limits"));
SELECT setval('security_logs_id_seq', (SELECT MAX(id) FROM "security_logs"));

-- Re-enable triggers
SET session_replication_role = 'origin';

COMMIT;

-- Verify data was inserted
SELECT 'Data migration completed: ' || COUNT(*)::text || ' tables populated' 
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('users', 'projects', 'project_plans', 'containers', 'llm_configs', 'llm_requests', 'pipeline_stages', 'project_logs');

