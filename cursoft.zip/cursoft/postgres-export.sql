-- Cursoft PostgreSQL Migration
-- Generated: 2025-12-29 01:41:42
-- Source: MySQL database 'cursoft'

-- ============================================
-- Table: agent_actions
-- ============================================
DROP TABLE IF EXISTS "agent_actions" CASCADE;

CREATE TABLE "agent_actions" (
  "id" INTEGER NOT NULL ,
  "project_id" INTEGER DEFAULT NULL,
  "pipeline_stage_id" INTEGER DEFAULT NULL,
  "agent_type" VARCHAR(50) NOT NULL COMMENT 'planner, coder, debugger, tester, etc.',
  "action_type" VARCHAR(100) NOT NULL COMMENT 'file_create, file_edit, code_execute, etc.',
  "action_description" TEXT DEFAULT NULL,
  "action_data" TEXT DEFAULT NULL COMMENT 'JSON format for action details',
  "result" enum('success','failed','warning') DEFAULT 'success',
  "error_message" TEXT DEFAULT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  KEY "pipeline_stage_id" ("pipeline_stage_id"),
  KEY "idx_project_id" ("project_id"),
  KEY "idx_agent_type" ("agent_type"),
  KEY "idx_action_type" ("action_type"),
  KEY "idx_created_at" ("created_at"),
  CONSTRAINT "agent_actions_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE CASCADE,
  CONSTRAINT "agent_actions_ibfk_2" FOREIGN KEY ("pipeline_stage_id") REFERENCES "pipeline_stages" ("id") ON DELETE SET NULL
)   COLLATE=utf8mb4_general_ci;

-- ============================================
-- Table: api_tokens
-- ============================================
DROP TABLE IF EXISTS "api_tokens" CASCADE;

CREATE TABLE "api_tokens" (
  "id" INTEGER NOT NULL ,
  "user_id" INTEGER NOT NULL,
  "token" VARCHAR(64) NOT NULL,
  "name" VARCHAR(255) DEFAULT NULL,
  "last_used_at" TIMESTAMP NULL DEFAULT NULL,
  "expires_at" TIMESTAMP NULL DEFAULT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  UNIQUE KEY "token" ("token"),
  KEY "idx_token" ("token"),
  KEY "idx_user_id" ("user_id"),
  CONSTRAINT "api_tokens_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
)   COLLATE=utf8mb4_general_ci;

-- ============================================
-- Table: container_logs
-- ============================================
DROP TABLE IF EXISTS "container_logs" CASCADE;

CREATE TABLE "container_logs" (
  "id" INTEGER NOT NULL ,
  "container_id" INTEGER NOT NULL,
  "log_level" enum('info','warning','error','success','debug') DEFAULT 'info',
  "message" TEXT NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  KEY "idx_container_id" ("container_id"),
  KEY "idx_created_at" ("created_at"),
  KEY "idx_log_level" ("log_level"),
  CONSTRAINT "container_logs_ibfk_1" FOREIGN KEY ("container_id") REFERENCES "containers" ("id") ON DELETE CASCADE
)  =5  COLLATE=utf8mb4_general_ci;

-- Data for container_logs (4 rows)
INSERT INTO "container_logs" ("id", "container_id", "log_level", "message", "created_at") VALUES ('1', '1', 'info', 'Container created: cursoft-project-3-1766964603', '2025-12-29 00:30:05');
INSERT INTO "container_logs" ("id", "container_id", "log_level", "message", "created_at") VALUES ('2', '2', 'info', 'Container created: cursoft-project-1-1766964606', '2025-12-29 00:30:07');
INSERT INTO "container_logs" ("id", "container_id", "log_level", "message", "created_at") VALUES ('3', '3', 'info', 'Container created: cursoft-project-5-1766964645', '2025-12-29 00:30:46');
INSERT INTO "container_logs" ("id", "container_id", "log_level", "message", "created_at") VALUES ('4', '4', 'info', 'Container created: cursoft-project-1-1766964646', '2025-12-29 00:30:47');

-- ============================================
-- Table: containers
-- ============================================
DROP TABLE IF EXISTS "containers" CASCADE;

CREATE TABLE "containers" (
  "id" INTEGER NOT NULL ,
  "project_id" INTEGER NOT NULL,
  "container_id" VARCHAR(255) DEFAULT NULL,
  "container_name" VARCHAR(255) NOT NULL,
  "image" VARCHAR(255) NOT NULL DEFAULT 'cursoft-dev:latest',
  "status" enum('created','running','stopped','paused','removed','error') DEFAULT 'created',
  "port_mapping" VARCHAR(255) DEFAULT NULL COMMENT 'Format: host:container',
  "environment_vars" TEXT DEFAULT NULL COMMENT 'JSON format',
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  "updated_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP() ON UPDATE current_TIMESTAMP(),
  "started_at" TIMESTAMP NULL DEFAULT NULL,
  "stopped_at" TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY ("id"),
  UNIQUE KEY "container_id" ("container_id"),
  KEY "idx_project_id" ("project_id"),
  KEY "idx_container_id" ("container_id"),
  KEY "idx_status" ("status"),
  CONSTRAINT "containers_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE CASCADE
)  =5  COLLATE=utf8mb4_general_ci;

-- Data for containers (4 rows)
INSERT INTO "containers" ("id", "project_id", "container_id", "container_name", "image", "status", "port_mapping", "environment_vars", "created_at", "updated_at", "started_at", "stopped_at") VALUES ('1', '3', 'b4cdef4884459029eadb138ce9a022e656f53fd35ba3c705d3d6ab01849dadff', 'cursoft-project-3-1766964603', 'cursoft-dev:latest', 'error', '8000:80', '{\"PROJECT_ID\":3,\"CURSOFT_ENV\":\"development\"}', '2025-12-29 00:30:05', '2025-12-29 00:30:06', NULL, NULL);
INSERT INTO "containers" ("id", "project_id", "container_id", "container_name", "image", "status", "port_mapping", "environment_vars", "created_at", "updated_at", "started_at", "stopped_at") VALUES ('2', '1', '9aa2414b6dfbda6b452f2a15d4eccb6c1c91a296a1dd457735b4792aafd03d41', 'cursoft-project-1-1766964606', 'cursoft-dev:latest', 'error', '8001:80', '{\"PROJECT_ID\":1,\"CURSOFT_ENV\":\"development\"}', '2025-12-29 00:30:07', '2025-12-29 00:30:46', NULL, NULL);
INSERT INTO "containers" ("id", "project_id", "container_id", "container_name", "image", "status", "port_mapping", "environment_vars", "created_at", "updated_at", "started_at", "stopped_at") VALUES ('3', '5', 'b8644067872819e567326074c5914e1620e0589ef00adca0a27e573b4499f2b2', 'cursoft-project-5-1766964645', 'cursoft-dev:latest', 'created', '8002:80', '{\"PROJECT_ID\":5,\"CURSOFT_ENV\":\"development\"}', '2025-12-29 00:30:46', '2025-12-29 00:30:46', NULL, NULL);
INSERT INTO "containers" ("id", "project_id", "container_id", "container_name", "image", "status", "port_mapping", "environment_vars", "created_at", "updated_at", "started_at", "stopped_at") VALUES ('4', '1', '525aa01139dac86971353d9c1730e070347daf700f640154772db8806c646aed', 'cursoft-project-1-1766964646', 'cursoft-dev:latest', 'created', '8003:80', '{\"PROJECT_ID\":1,\"CURSOFT_ENV\":\"development\"}', '2025-12-29 00:30:47', '2025-12-29 00:30:47', NULL, NULL);

-- ============================================
-- Table: llm_configs
-- ============================================
DROP TABLE IF EXISTS "llm_configs" CASCADE;

CREATE TABLE "llm_configs" (
  "id" INTEGER NOT NULL ,
  "user_id" INTEGER NOT NULL,
  "provider" VARCHAR(50) NOT NULL COMMENT 'openai, anthropic, google, deepseek, ollama',
  "api_key" VARCHAR(500) NOT NULL,
  "model" VARCHAR(100) DEFAULT NULL,
  "enabled" tinyINTEGER DEFAULT 1,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  KEY "idx_user_id" ("user_id"),
  KEY "idx_provider" ("provider"),
  CONSTRAINT "llm_configs_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
)  =9  COLLATE=utf8mb4_general_ci;

-- Data for llm_configs (8 rows)
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES ('1', '1', 'ollama', 'local', 'llama2', '1', '2025-12-29 00:44:02');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES ('2', '1', 'openai', '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', '', '1', '2025-12-29 00:44:36');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES ('3', '1', 'anthropic', 'test-key-replace-with-real-key', 'claude-3-haiku', '1', '2025-12-29 00:44:36');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES ('4', '1', 'google', 'test-key-replace-with-real-key', 'gemini-pro', '1', '2025-12-29 00:44:36');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES ('5', '1', 'deepseek', 'test-key-replace-with-real-key', 'deepseek-chat', '1', '2025-12-29 00:44:36');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES ('6', '1', 'ollama', 'local', 'llama2', '1', '2025-12-29 00:44:36');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES ('7', '1', 'ollama', 'local', 'llama2', '1', '2025-12-29 00:44:59');
INSERT INTO "llm_configs" ("id", "user_id", "provider", "api_key", "model", "enabled", "created_at") VALUES ('8', '2', 'openai', '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', '', '1', '2025-12-29 01:03:33');

-- ============================================
-- Table: llm_requests
-- ============================================
DROP TABLE IF EXISTS "llm_requests" CASCADE;

CREATE TABLE "llm_requests" (
  "id" INTEGER NOT NULL ,
  "project_id" INTEGER DEFAULT NULL,
  "provider" VARCHAR(50) NOT NULL COMMENT 'openai, anthropic, google, deepseek, ollama',
  "model" VARCHAR(100) NOT NULL,
  "prompt" TEXT NOT NULL,
  "response" TEXT DEFAULT NULL,
  "tokens_input" INTEGER DEFAULT 0,
  "tokens_output" INTEGER DEFAULT 0,
  "tokens_total" INTEGER DEFAULT 0,
  "cost_usd" decimal(10,6) DEFAULT 0.000000,
  "status" enum('pending','completed','failed','timeout') DEFAULT 'pending',
  "error_message" TEXT DEFAULT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  "completed_at" TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY ("id"),
  KEY "idx_project_id" ("project_id"),
  KEY "idx_provider" ("provider"),
  KEY "idx_status" ("status"),
  KEY "idx_created_at" ("created_at"),
  CONSTRAINT "llm_requests_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE SET NULL
)  =7  COLLATE=utf8mb4_general_ci;

-- Data for llm_requests (6 rows)
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES ('1', NULL, 'openai', '', 'Write a simple PHP function that calculates the factorial of a number.', NULL, '0', '0', '0', '0.000000', 'failed', 'API error (HTTP 401): {\n    \"error\": {\n        \"message\": \"Incorrect API key provided: test-key******************-key. You can find your API key at https://platform.openai.com/account/api-keys.\",\n        \"type\": \"invalid_request_error\",\n        \"param\": null,\n        \"code\": \"invalid_api_key\"\n    }\n}\n', '2025-12-29 00:45:46', '2025-12-29 00:45:46');
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES ('2', NULL, 'anthropic', '', 'Write a simple PHP function that calculates the factorial of a number.', NULL, '0', '0', '0', '0.000000', 'failed', 'API error (HTTP 401): {\"type\":\"error\",\"error\":{\"type\":\"authentication_error\",\"message\":\"invalid x-api-key\"},\"request_id\":\"req_011CWZyZBsH8svrh4bALwA8c\"}', '2025-12-29 00:45:56', '2025-12-29 00:45:56');
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES ('3', NULL, 'openai', '', 'Write a simple PHP function that calculates the factorial of a number.', NULL, '0', '0', '0', '0.000000', 'failed', 'API error (HTTP 401): {\n    \"error\": {\n        \"message\": \"Incorrect API key provided: test-key******************-key. You can find your API key at https://platform.openai.com/account/api-keys.\",\n        \"type\": \"invalid_request_error\",\n        \"param\": null,\n        \"code\": \"invalid_api_key\"\n    }\n}\n', '2025-12-29 00:47:29', '2025-12-29 00:47:29');
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES ('4', NULL, 'openai', '', 'Write a simple PHP function that calculates the factorial of a number.', NULL, '0', '0', '0', '0.000000', 'failed', 'Invalid API key. Please check your API key in the LLM Configuration page. If you\'re using a test key, replace it with a real API key from the provider.', '2025-12-29 00:47:58', '2025-12-29 00:47:58');
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES ('5', NULL, 'openai', '', 'Write a simple PHP function that calculates the factorial of a number.', NULL, '0', '0', '0', '0.000000', 'failed', 'you must provide a model parameter', '2025-12-29 00:52:28', '2025-12-29 00:52:28');
INSERT INTO "llm_requests" ("id", "project_id", "provider", "model", "prompt", "response", "tokens_input", "tokens_output", "tokens_total", "cost_usd", "status", "error_message", "created_at", "completed_at") VALUES ('6', NULL, 'openai', 'gpt-3.5-turbo', 'Write a simple PHP function that calculates the factorial of a number.', '```php\nfunction factorial($n) {\n    if($n == 0) {\n        return 1;\n    } else {\n        return $n * factorial($n - 1);\n    }\n}\n\n// Example usage\necho factorial(5); // Output: 120\n```', '20', '58', '78', '0.000146', 'completed', NULL, '2025-12-29 00:52:47', '2025-12-29 00:52:49');

-- ============================================
-- Table: password_reset_tokens
-- ============================================
DROP TABLE IF EXISTS "password_reset_tokens" CASCADE;

CREATE TABLE "password_reset_tokens" (
  "id" INTEGER NOT NULL ,
  "user_id" INTEGER NOT NULL,
  "token" VARCHAR(64) NOT NULL,
  "expires_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP() ON UPDATE current_TIMESTAMP(),
  "used" tinyINTEGER DEFAULT 0,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  KEY "idx_token" ("token"),
  KEY "idx_user_id" ("user_id"),
  KEY "idx_expires_at" ("expires_at"),
  CONSTRAINT "password_reset_tokens_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
)   COLLATE=utf8mb4_general_ci;

-- ============================================
-- Table: pipeline_stages
-- ============================================
DROP TABLE IF EXISTS "pipeline_stages" CASCADE;

CREATE TABLE "pipeline_stages" (
  "id" INTEGER NOT NULL ,
  "project_id" INTEGER NOT NULL,
  "stage_name" VARCHAR(100) NOT NULL COMMENT 'planning, coding, testing, deployment, etc.',
  "stage_order" INTEGER NOT NULL,
  "status" enum('pending','running','completed','failed','skipped') DEFAULT 'pending',
  "started_at" TIMESTAMP NULL DEFAULT NULL,
  "completed_at" TIMESTAMP NULL DEFAULT NULL,
  "error_message" TEXT DEFAULT NULL,
  "output_data" TEXT DEFAULT NULL COMMENT 'JSON format for stage results',
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  KEY "idx_project_id" ("project_id"),
  KEY "idx_status" ("status"),
  KEY "idx_stage_order" ("stage_order"),
  CONSTRAINT "pipeline_stages_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE CASCADE
)  =8  COLLATE=utf8mb4_general_ci;

-- Data for pipeline_stages (7 rows)
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES ('1', '6', 'planning', '1', 'completed', '2025-12-29 01:02:43', '2025-12-29 01:02:43', NULL, '{\"tasks\":3,\"message\":\"Planning completed\"}', '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES ('2', '6', 'environment', '2', 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES ('3', '6', 'development', '3', 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES ('4', '6', 'testing', '4', 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES ('5', '6', 'integration', '5', 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES ('6', '6', 'deployment', '6', 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');
INSERT INTO "pipeline_stages" ("id", "project_id", "stage_name", "stage_order", "status", "started_at", "completed_at", "error_message", "output_data", "created_at") VALUES ('7', '6', 'final', '7', 'pending', NULL, NULL, NULL, NULL, '2025-12-29 01:02:43');

-- ============================================
-- Table: project_logs
-- ============================================
DROP TABLE IF EXISTS "project_logs" CASCADE;

CREATE TABLE "project_logs" (
  "id" INTEGER NOT NULL ,
  "project_id" INTEGER NOT NULL,
  "log_level" enum('info','warning','error','success') DEFAULT 'info',
  "message" TEXT NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  KEY "idx_project_id" ("project_id"),
  KEY "idx_created_at" ("created_at"),
  CONSTRAINT "project_logs_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE CASCADE
)  =13  COLLATE=utf8mb4_general_ci;

-- Data for project_logs (12 rows)
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('1', '1', 'info', 'Project created: test1', '2025-12-28 23:54:32');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('2', '1', 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-28 23:54:32');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('3', '2', 'info', 'Project created: Test Project 1766964603', '2025-12-29 00:30:03');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('4', '2', 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-29 00:30:03');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('5', '3', 'info', 'Project created: Decomposition Test', '2025-12-29 00:30:03');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('6', '3', 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-29 00:30:03');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('7', '4', 'info', 'Project created: Test Project 1766964645', '2025-12-29 00:30:45');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('8', '4', 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-29 00:30:45');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('9', '5', 'info', 'Project created: Decomposition Test', '2025-12-29 00:30:45');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('10', '5', 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-29 00:30:45');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('11', '6', 'info', 'Project created: Ayhan', '2025-12-29 01:02:37');
INSERT INTO "project_logs" ("id", "project_id", "log_level", "message", "created_at") VALUES ('12', '6', 'info', 'Prompt analyzed and decomposed into tasks', '2025-12-29 01:02:37');

-- ============================================
-- Table: project_plans
-- ============================================
DROP TABLE IF EXISTS "project_plans" CASCADE;

CREATE TABLE "project_plans" (
  "id" INTEGER NOT NULL ,
  "project_id" INTEGER NOT NULL,
  "task_order" INTEGER NOT NULL,
  "task_name" VARCHAR(255) NOT NULL,
  "task_description" TEXT DEFAULT NULL,
  "estimated_time" INTEGER DEFAULT NULL COMMENT 'Minutes',
  "status" enum('pending','in_progress','completed','failed') DEFAULT 'pending',
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  KEY "idx_project_id" ("project_id"),
  KEY "idx_status" ("status"),
  CONSTRAINT "project_plans_ibfk_1" FOREIGN KEY ("project_id") REFERENCES "projects" ("id") ON DELETE CASCADE
)  =31  COLLATE=utf8mb4_general_ci;

-- Data for project_plans (30 rows)
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('1', '1', '1', 'Project Setup', 'Initialize project structure and dependencies', '15', 'pending', '2025-12-28 23:54:32');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('2', '1', '2', 'Testing', 'Write and run unit and integration tests', '30', 'pending', '2025-12-28 23:54:32');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('3', '1', '3', 'Documentation', 'Create README and API documentation', '15', 'pending', '2025-12-28 23:54:32');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('4', '2', '1', 'Project Setup', 'Initialize project structure and dependencies', '15', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('5', '2', '2', 'Frontend Setup', 'Create HTML/CSS/JavaScript structure', '30', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('6', '2', '3', 'Backend API', 'Develop REST API endpoints', '45', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('7', '2', '4', 'Database Design', 'Create database schema and migrations', '20', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('8', '2', '5', 'Database Schema', 'Design and implement database structure', '25', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('9', '2', '6', 'Authentication System', 'Implement user registration and login', '40', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('10', '2', '7', 'Testing', 'Write and run unit and integration tests', '30', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('11', '2', '8', 'Documentation', 'Create README and API documentation', '15', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('12', '3', '1', 'Project Setup', 'Initialize project structure and dependencies', '15', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('13', '3', '2', 'API Development', 'Create RESTful API endpoints', '50', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('14', '3', '3', 'Testing', 'Write and run unit and integration tests', '30', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('15', '3', '4', 'Documentation', 'Create README and API documentation', '15', 'pending', '2025-12-29 00:30:03');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('16', '4', '1', 'Project Setup', 'Initialize project structure and dependencies', '15', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('17', '4', '2', 'Frontend Setup', 'Create HTML/CSS/JavaScript structure', '30', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('18', '4', '3', 'Backend API', 'Develop REST API endpoints', '45', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('19', '4', '4', 'Database Design', 'Create database schema and migrations', '20', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('20', '4', '5', 'Database Schema', 'Design and implement database structure', '25', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('21', '4', '6', 'Authentication System', 'Implement user registration and login', '40', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('22', '4', '7', 'Testing', 'Write and run unit and integration tests', '30', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('23', '4', '8', 'Documentation', 'Create README and API documentation', '15', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('24', '5', '1', 'Project Setup', 'Initialize project structure and dependencies', '15', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('25', '5', '2', 'API Development', 'Create RESTful API endpoints', '50', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('26', '5', '3', 'Testing', 'Write and run unit and integration tests', '30', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('27', '5', '4', 'Documentation', 'Create README and API documentation', '15', 'pending', '2025-12-29 00:30:45');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('28', '6', '1', 'Project Setup', 'Initialize project structure and dependencies', '15', 'pending', '2025-12-29 01:02:37');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('29', '6', '2', 'Testing', 'Write and run unit and integration tests', '30', 'pending', '2025-12-29 01:02:37');
INSERT INTO "project_plans" ("id", "project_id", "task_order", "task_name", "task_description", "estimated_time", "status", "created_at") VALUES ('30', '6', '3', 'Documentation', 'Create README and API documentation', '15', 'pending', '2025-12-29 01:02:37');

-- ============================================
-- Table: projects
-- ============================================
DROP TABLE IF EXISTS "projects" CASCADE;

CREATE TABLE "projects" (
  "id" INTEGER NOT NULL ,
  "user_id" INTEGER NOT NULL,
  "name" VARCHAR(255) NOT NULL,
  "prompt" TEXT NOT NULL,
  "status" enum('planning','active','completed','failed','paused') DEFAULT 'planning',
  "progress" INTEGER DEFAULT 0,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  "updated_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP() ON UPDATE current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  KEY "idx_user_id" ("user_id"),
  KEY "idx_status" ("status"),
  CONSTRAINT "projects_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
)  =7  COLLATE=utf8mb4_general_ci;

-- Data for projects (6 rows)
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES ('1', '1', 'test1', 'test pagina hello ayhan', 'planning', '0', '2025-12-28 23:54:32', '2025-12-28 23:54:32');
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES ('2', '1', 'Test Project 1766964603', 'Build a todo web app with user authentication and MySQL database', 'planning', '0', '2025-12-29 00:30:03', '2025-12-29 00:30:03');
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES ('3', '1', 'Decomposition Test', 'Create a REST API for a blog system', 'planning', '0', '2025-12-29 00:30:03', '2025-12-29 00:30:03');
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES ('4', '1', 'Test Project 1766964645', 'Build a todo web app with user authentication and MySQL database', 'planning', '0', '2025-12-29 00:30:45', '2025-12-29 00:30:45');
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES ('5', '1', 'Decomposition Test', 'Create a REST API for a blog system', 'planning', '0', '2025-12-29 00:30:45', '2025-12-29 00:30:45');
INSERT INTO "projects" ("id", "user_id", "name", "prompt", "status", "progress", "created_at", "updated_at") VALUES ('6', '2', 'Ayhan', 'create a hello Cursoft landingspage', 'active', '14', '2025-12-29 01:02:37', '2025-12-29 01:02:43');

-- ============================================
-- Table: rate_limits
-- ============================================
DROP TABLE IF EXISTS "rate_limits" CASCADE;

CREATE TABLE "rate_limits" (
  "id" INTEGER NOT NULL ,
  "identifier" VARCHAR(100) NOT NULL,
  "ip_address" VARCHAR(45) NOT NULL,
  "request_count" INTEGER DEFAULT 1,
  "reset_time" INTEGER NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  KEY "idx_identifier_ip" ("identifier","ip_address"),
  KEY "idx_reset_time" ("reset_time")
)   COLLATE=utf8mb4_general_ci;

-- ============================================
-- Table: security_logs
-- ============================================
DROP TABLE IF EXISTS "security_logs" CASCADE;

CREATE TABLE "security_logs" (
  "id" INTEGER NOT NULL ,
  "event_type" VARCHAR(100) NOT NULL,
  "ip_address" VARCHAR(45) DEFAULT NULL,
  "user_agent" TEXT DEFAULT NULL,
  "user_id" INTEGER DEFAULT NULL,
  "event_data" longTEXT CHARACTER SET utf8mb4  DEFAULT NULL CHECK (json_valid("event_data")),
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  KEY "idx_event_type" ("event_type"),
  KEY "idx_user_id" ("user_id"),
  KEY "idx_created_at" ("created_at"),
  CONSTRAINT "security_logs_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE SET NULL
)   COLLATE=utf8mb4_general_ci;

-- ============================================
-- Table: user_preferences
-- ============================================
DROP TABLE IF EXISTS "user_preferences" CASCADE;

CREATE TABLE "user_preferences" (
  "id" INTEGER NOT NULL ,
  "user_id" INTEGER NOT NULL,
  "theme" VARCHAR(20) DEFAULT 'light' COMMENT 'light, dark',
  "language" VARCHAR(10) DEFAULT 'en',
  "notifications_enabled" tinyINTEGER DEFAULT 1,
  "email_notifications" tinyINTEGER DEFAULT 1,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  "updated_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP() ON UPDATE current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  UNIQUE KEY "user_id" ("user_id"),
  KEY "idx_user_id" ("user_id"),
  CONSTRAINT "user_preferences_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
)  =2  COLLATE=utf8mb4_general_ci;

-- Data for user_preferences (1 rows)
INSERT INTO "user_preferences" ("id", "user_id", "theme", "language", "notifications_enabled", "email_notifications", "created_at", "updated_at") VALUES ('1', '2', 'light', 'en', '1', '1', '2025-12-29 01:01:37', '2025-12-29 01:01:37');

-- ============================================
-- Table: user_sessions
-- ============================================
DROP TABLE IF EXISTS "user_sessions" CASCADE;

CREATE TABLE "user_sessions" (
  "id" INTEGER NOT NULL ,
  "user_id" INTEGER NOT NULL,
  "session_token" VARCHAR(255) NOT NULL,
  "ip_address" VARCHAR(45) DEFAULT NULL,
  "user_agent" TEXT DEFAULT NULL,
  "expires_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP() ON UPDATE current_TIMESTAMP(),
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  "last_activity" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP() ON UPDATE current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  UNIQUE KEY "session_token" ("session_token"),
  KEY "idx_user_id" ("user_id"),
  KEY "idx_session_token" ("session_token"),
  KEY "idx_expires_at" ("expires_at"),
  CONSTRAINT "user_sessions_ibfk_1" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
)  =2  COLLATE=utf8mb4_general_ci;

-- Data for user_sessions (1 rows)
INSERT INTO "user_sessions" ("id", "user_id", "session_token", "ip_address", "user_agent", "expires_at", "created_at", "last_activity") VALUES ('1', '2', 'b53951d238ad7516687899116b0b4e8e676b61cebb54c568232610bcfc120e95', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/2.2.44 Chrome/138.0.7204.251 Electron/37.7.0 Safari/537.36', '2025-12-30 01:02:11', '2025-12-29 01:02:11', '2025-12-29 01:02:11');

-- ============================================
-- Table: users
-- ============================================
DROP TABLE IF EXISTS "users" CASCADE;

CREATE TABLE "users" (
  "id" INTEGER NOT NULL ,
  "email" VARCHAR(255) NOT NULL,
  "password_hash" VARCHAR(255) NOT NULL,
  "name" VARCHAR(255) NOT NULL,
  "created_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP(),
  "updated_at" TIMESTAMP NOT NULL DEFAULT current_TIMESTAMP() ON UPDATE current_TIMESTAMP(),
  PRIMARY KEY ("id"),
  UNIQUE KEY "email" ("email"),
  KEY "idx_email" ("email")
)  =3  COLLATE=utf8mb4_general_ci;

-- Data for users (2 rows)
INSERT INTO "users" ("id", "email", "password_hash", "name", "created_at", "updated_at") VALUES ('1', 'test@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Test User', '2025-12-28 23:52:02', '2025-12-28 23:52:02');
INSERT INTO "users" ("id", "email", "password_hash", "name", "created_at", "updated_at") VALUES ('2', 'ayhan@ayhan.nl', '$2y$10$8BzFyfav10jaRUrnHQJT1u7hUlnDzwvASaeAXDorcl34BHCjdME16', 'ayhan', '2025-12-29 01:01:37', '2025-12-29 01:01:37');

