# 🚀 Push Command - Copy & Run This

## ✅ Use Your Token

Run this command in PowerShell:

```powershell
git push https://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@github.com/AyhanEkici/cursoft.git main
```

Or set upstream and push:

```powershell
git push -u origin main
```

**When prompted:**
- Username: `AyhanEkici`
- Password: `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`

## ✅ After Push

1. **Verify on GitHub:**
   - Visit: https://github.com/AyhanEkici/cursoft
   - Should see all your files!

2. **Next: Render Deployment**
   - Go to Render dashboard
   - Connect repository
   - Deploy!

---

**Run the push command above in your PowerShell terminal!**

