/**
 * API Client for Cursoft
 * Handles all API calls to the backend
 */

const API_BASE = '/cursoft/api';

class APIClient {
    /**
     * Make API request
     */
    async request(endpoint, options = {}) {
        const url = API_BASE + endpoint;
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };
        
        if (options.body && typeof options.body === 'object') {
            config.body = JSON.stringify(options.body);
        }
        
        try {
            const response = await fetch(url, config);
            const data = await response.json();
            
            if (!response.ok) {
                throw new Error(data.error || 'API request failed');
            }
            
            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }
    
    /**
     * Authentication
     */
    async login(email, password, rememberMe = false) {
        return this.request('/auth.php', {
            method: 'POST',
            body: {
                action: 'login',
                email,
                password,
                remember_me: rememberMe
            }
        });
    }
    
    async signup(email, password, name) {
        return this.request('/auth.php', {
            method: 'POST',
            body: {
                action: 'signup',
                email,
                password,
                name
            }
        });
    }
    
    async logout() {
        return this.request('/auth.php', {
            method: 'POST',
            body: { action: 'logout' }
        });
    }
    
    async checkAuth() {
        return this.request('/auth.php?check=1');
    }
    
    /**
     * Projects
     */
    async createProject(userId, name, prompt) {
        return this.request('/projects.php', {
            method: 'POST',
            body: {
                user_id: userId,
                name,
                prompt
            }
        });
    }
    
    async getProject(projectId) {
        return this.request(`/projects.php?id=${projectId}`);
    }
    
    async getUserProjects(userId) {
        return this.request(`/projects.php?user_id=${userId}`);
    }
    
    /**
     * Containers
     */
    async createContainer(projectId, options = {}) {
        return this.request('/containers.php', {
            method: 'POST',
            body: {
                project_id: projectId,
                ...options
            }
        });
    }
    
    async getContainers(projectId = null) {
        const url = projectId 
            ? `/containers.php?project_id=${projectId}`
            : '/containers.php';
        return this.request(url);
    }
    
    async containerAction(containerId, action) {
        return this.request('/containers.php', {
            method: 'PUT',
            body: {
                id: containerId,
                action
            }
        });
    }
    
    /**
     * LLM
     */
    async makeLLMRequest(userId, provider, prompt, options = {}) {
        return this.request('/llm.php', {
            method: 'POST',
            body: {
                user_id: userId,
                provider,
                prompt,
                ...options
            }
        });
    }
    
    /**
     * Pipeline
     */
    async startPipeline(projectId, options = {}) {
        return this.request('/pipeline.php', {
            method: 'POST',
            body: {
                project_id: projectId,
                action: 'start',
                ...options
            }
        });
    }
    
    async getPipelineStatus(projectId) {
        return this.request(`/pipeline.php?project_id=${projectId}`);
    }
    
    async executeStage(projectId, stage, options = {}) {
        return this.request('/pipeline.php', {
            method: 'POST',
            body: {
                project_id: projectId,
                action: 'execute_stage',
                stage,
                ...options
            }
        });
    }
}

// Create global instance
const api = new APIClient();

